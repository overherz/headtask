<?php

$name = "%blank%";

$submenu['content'] = array(
  //  '%blank%' => '%blank%'
);

$icon = false;

$router = array(
//    'fake_controller' => array('application' => 'portfolio', 'controller' => 'real_controller'),
);

$router_admin = array(
//    'fake_controller' => array('application' => 'portfolio', 'controller' => 'real_controller'),
);

$func_from_text = array(
//    'get_news' => array('application' => 'news','controller' => 'news','function' => 'get_n_news'),
);

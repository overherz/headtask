<?php
namespace admin\%blank%;

class %blank% extends \Admin {

    function default_method()
    {
        $this->layout_show('admin/index.html');
    }
}

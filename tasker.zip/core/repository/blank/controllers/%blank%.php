<?php
namespace %blank%;

class %blank% extends \Controller {  
    
    function default_method()
    {
        $this->layout_show('index.html');
    }
}

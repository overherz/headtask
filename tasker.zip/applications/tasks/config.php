<?php

$name = "tasks";

$submenu['options'] = array(
    'tasks' => 'Планировщик задач'
);

$router = array(
//    'fake_controller' => array('application' => 'rooms', 'controller' => 'real_controller'),
);

$router_admin = array(
//    'fake_controller' => array('application' => 'rooms', 'controller' => 'real_controller'),
);



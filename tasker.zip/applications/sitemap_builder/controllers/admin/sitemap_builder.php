<?php
namespace admin\sitemap_builder;

class sitemap_builder extends \Admin {

    function default_method()
    {
        $this->layout_show('admin/index.html');
    }
}

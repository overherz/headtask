<?php
namespace admin\sitemap;

class sitemap extends \Admin {

    function default_method()
    {
        $this->layout_show('admin/index.html');
    }
}

<?php

$name = "black_list";

$submenu['options'] = array(
 //   'black_list' => 'Черный список'
);

$router = array(
//    'fake_controller' => array('application' => 'portfolio', 'controller' => 'real_controller'),
);

$router_admin = array(
//    'fake_controller' => array('application' => 'portfolio', 'controller' => 'real_controller'),
);


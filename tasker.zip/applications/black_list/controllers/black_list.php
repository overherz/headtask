<?php
namespace black_list;

class black_list extends \Controller {  
    
    function default_method()
    {
        $this->layout_show('index.html');
    }
}


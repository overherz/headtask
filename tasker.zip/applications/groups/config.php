<?php

$name = "Группы";

$submenu['users'] = array(
    'groups' => 'Группы'
);



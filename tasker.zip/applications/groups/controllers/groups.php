<?php
namespace groups;

class groups extends \Controller {  
    
    function default_method()
    {
        $this->layout_show('index.html');
    }
}


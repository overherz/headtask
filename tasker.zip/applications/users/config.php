<?php

$name = "Пользователи";

$submenu['users'] = array(
    'users' => 'Пользователи'
);



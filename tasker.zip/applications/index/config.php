<?php

$name = "Главная";

$submenu['users'] = array(
   // 'groups' => 'Группы'
);



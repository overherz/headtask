<?php
namespace admin\mail;

class mail extends \Admin {

    function default_method()
    {
        $this->layout_show('admin/index.html');
    }
}
?>

<?php
namespace mail;

class mail extends \Controller {  
    
    function default_method()
    {
        $this->layout_show('index.html');
    }
}
?>

<?php

$name = "mail";

$submenu['content'] = array(
  //  'mail' => 'mail'
);

$router = array(
//    'fake_controller' => array('application' => 'portfolio', 'controller' => 'real_controller'),
);

$router_admin = array(
//    'fake_controller' => array('application' => 'portfolio', 'controller' => 'real_controller'),
);
?>

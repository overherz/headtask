<?php

$name = "Меню";

$submenu['content'] = array(
    'menu' => 'Меню'
);

$icon = "fa-sitemap";



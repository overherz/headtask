<?php
namespace admin\projects;

class projects extends \Admin {

    function default_method()
    {
        $this->layout_show('admin/index.html');
    }
}
?>

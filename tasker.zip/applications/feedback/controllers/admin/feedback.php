<?php
namespace admin\feedback;

class feedback extends \Admin {

    function default_method()
    {
        $this->layout_show('admin/index.html');
    }
}


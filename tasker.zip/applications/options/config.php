<?php

$name = "Настройки";

$submenu['options'] = array(
    'options' => 'Категории',
    'constructor' => 'Конструктор'
);

$icon = "fa-cog";



<?php
namespace options;

class options extends \Controller {  
    
    function default_method()
    {
        $this->layout_show('index.html');
    }
}


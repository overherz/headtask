<?php

$name = "Логи";

$submenu['options'] = array(
    'logs' => 'Авторизация',
    'admin' => 'Действия в панели'
);

$icon = "fa-list-ul";



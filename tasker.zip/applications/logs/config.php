<?php

$name = "Логи";

$submenu['options'] = array(
    'logs' => 'Авторизация',
    'admin' => 'Действия в панеле'
);

$icon = "fa-list-ul";


